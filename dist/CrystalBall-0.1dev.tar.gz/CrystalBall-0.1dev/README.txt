=============
Crystal Ball  
=============

Crystal Ball is a simple app in which you ask a question 
and the crystal ball guides you.  

=============
Requirements 
=============
    Python2 or later 
    Python3 (Recommended)
    pip
    Pillow 
    
